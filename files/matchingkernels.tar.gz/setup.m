
if(isempty(getenv('MATCHING_KERNEL_SETUP')))
    
    % Internal paths
    addpath('src');
    addpath('.');
    
    LIBSVMPATH = '~/programdev/lib/libsvm';
    GAIMCPATH = '~/programdev/lib/matlab/gaimc';
    
    if ~exist('src/svm_write_data.m*','file')
        cd src;
        mex svm_write_data.c;
        cd ..
    end
    
    % Set environment variables
    setenv('LIBSVMHOME',LIBSVMPATH);
    setenv('DIR_RESULTS','results');
    setenv('DIR_DATA','~/programdev/datasets/graphs');
    setenv('DIR_EMBEDS','~/programdev/datasets/graphs/lovasz');

    % Add to matlab path
    LIBSVMPATH = [getenv('LIBSVMHOME'),'/matlab'];
    
    addpath(LIBSVMPATH,GAIMCPATH);
    
    clear LIBSVMPATH GAIMCPATH;
    
    setenv('MATCHING_KERNEL_SETUP','1');
end
