function S = log_experiment(opt,R,T,onlyLabelCv)

[a gitrev] = unix('git rev-parse --verify HEAD');
S = '';
if a==0
    S = sprintf('-- Git revision: --\n\n%s\n',gitrev);
end

[m maxI] = max([R.cv]);

S = sprintf('%s\n-- Options: --%s',S,log_opt(opt,0));

S = sprintf('%s\n\n-- Results: --',S);
for i = 1:length(R)
    r = R(i);
    if nargin < 4 || ~onlyLabelCv
        S = sprintf('%s\n\n-- %s: --',S,r.label);
        r = rmfield(r,'label');
        S = sprintf('%s%s',S,log_opt(r,0));
    else
        if i==maxI
            S = sprintf('%s\n%.4f * %s',S,r.cv,r.label);
        else
            S = sprintf('%s\n%.4f   %s',S,r.cv,r.label);
        end
    end
end


function S = log_opt(opt,l)

simpleOpt = struct();
structNames = {};
structOpt = {};
stringOpt = {};
fields = fieldnames(opt);

S = '';

sp = repmat(' ',1,2*l);
spn = repmat(' ',1,2*(l+1));

for i = 1:numel(fields)
  v = opt.(fields{i});
  if(isstruct(v) && length(v)==1)
    Si = log_opt(v,l+1);
    structNames{end+1} = fields{i};
    structOpt{end+1} = Si;
  elseif(isstruct(v) && length(v)>1)
    S = sprintf('%s\n%s%s: <struct array>',S,sp,fields{i});
  elseif(iscell(v) && length(v)>1)
    S = sprintf('%s\n%s%s: <cell array>',S,sp,fields{i});
  elseif(ischar(v))
    stringOpt{end+1} = {fields{i},v};
    S = sprintf('%s\n%s%s: %s',S,sp,fields{i},v);
  else
    S = sprintf('%s\n%s%s: %s',S,sp,fields{i},strtrim(evalc(['disp(v)'])));
  end
end

level = repmat('+',1,l+1);

for i=1:length(structOpt)
    S = sprintf('%s\n\n%s-- %s: --%s%s',S,spn,structNames{i},evalc(['disp(structOpt{i})']));
end