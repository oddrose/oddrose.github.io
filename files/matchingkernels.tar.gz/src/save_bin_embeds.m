function save_bin_embeds(Us,path)

N = length(Us);
for i=1:N
    A = Us{i}';
    fname = sprintf('%s/%d.bin',path,i);
    fid = fopen(fname,'w');
    fwrite(fid,size(A),'int32');
    fwrite(fid,A,'float');
    fclose(fid);
end