function [embeds maxd maxm] = embed_graphs(graphs,verbose)

if(nargin<2)
    verbose = false;
end

N = length(graphs);
embeds = [];
maxd = 0;
maxm = 0;
if verbose
    fprintf(1,'Embedding graphs...\n')
end
for i=1:N
    if verbose
        progresscount(i,1,N);
    end
    
    E = embed_graph(graphs(i).am);
    if i==1
        embeds = E;
    else
        embeds(i) = E;
    end
    maxd = max(maxd,size(graphs(i).am,1));
    maxm = max(maxm,sum(sum(graphs(i).am)));
end
