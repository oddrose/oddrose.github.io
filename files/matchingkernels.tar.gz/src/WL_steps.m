function [K t] = WL_steps(Graphs,h,nl,verbose)

if nargin<4
    verbose = false;
end

labels = WLlabels(Graphs,h,nl,verbose);

N = length(Graphs);

K = zeros(N,N);
ts = [];
for k=1:length(labels)
    k
   Graphs_k = Graphs;
   for l=1:N
       Graphs_k(l).nl.values = labels{k}{l};
   end
   [Kks tk] = WL(Graphs_k,0,nl,verbose);
   Kks{1}(1,1)
   K = K+Kks{1};
   ts(end+1) = tk;
   clear Kks tk;
end

t = sum(ts);