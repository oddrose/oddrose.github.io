function newpath = filename_increment(filepath,reg,maxnum)

if(nargin<1)
    filepath = '~/test/test.txt';
end
if(nargin<2)
    reg = '%s_%d';
end
if(nargin<3)
    maxnum = 1000;
end

% If no such file, return original
if(exist(filepath) ~= 2)
    newpath = filepath;
    return;
else
    [path, name, ext] = fileparts(filepath);

    addPath = true;
    if(length(path)<1)
        addPath = false;
    end

    addExt = true;
    if(length(ext)<1)
        addExt = false;
    end
    
    e = (exist(filepath) == 2);
    i=1;
    while(e)
        if(i>maxnum)
            error('over maxnum files');
            break;
        end
        newname = sprintf(reg,name,i);
        if(addPath)            
            newpath = sprintf('%s/%s',path,newname);
        else
            newpath = newname;
        end
        if(addExt)
            newpath = sprintf('%s%s',newpath,ext);
        end
        e = (exist(newpath) == 2);
        
        i=i+1;
    end
end

