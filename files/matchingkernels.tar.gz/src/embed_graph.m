function embeds = embed_graph(A)

e = 10^(-5);

% Incidence Matrix
IM = incidence_matrix(sparse(A));

% Normalized laplacian
L = chol(graph_laplacian(A,true)+e*eye(size(A,1))); 

% Inverse laplacian
IL = chol(inverse_graph_laplacian(A)+e*eye(size(A,1)));

% Eigen-spectrum
if(issparse(A))
    [ES,D] = eig(full(A)); 
else
    [ES,D] = eig(A); 
end

% Laplacian eigen-spectrum
[ELS,DL] = eig(L); 

% LS-labelling
LS = ls_labelling(A);

embeds = struct();
embeds.IM = IM;
embeds.L = L;
embeds.IL = IL;
embeds.ES = ES;
embeds.ELS = ELS;
embeds.LS = LS;
