function [I,L] = inverse_graph_laplacian(A,L)

if nargin<2
    L = graph_laplacian(A,true);
end

try
    I = pinv(L);
catch
    keyboard
end