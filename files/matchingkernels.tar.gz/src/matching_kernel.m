function [K K_i tk] = matching_kernel(U,sim,nls,verbose,labelFun)

useLabels = false;
if nargin<3
   nls = []; 
end
if isempty(nls)
    useLabels = false;
else
    useLabels = true;
end

if(nargin<4)
    verbose = false;
end
if(nargin<5)
    labelFun = 'sum';
end
if nargin<2
    sim = 'cosine';
end

N = length(U);

% -- Indefinite kernel
if verbose
    fprintf(1,'Computing matching kernel...\n');
end
K = zeros(N,N);
tk = clock;
for i=1:N
    if verbose
        progresscount(i,1,N);
    end
    
    tp = 0;
    tm = 0;
    tw = 0;
    twio = 0;
    tb = 0;
    ts = 0;
    for j=i:N
        t=cputime;
        
        if strcmp(sim,'euclidean')
            %D = pdist2(U{i}',U{j}','euclidean'); % Incredibly slow!
            
            % Below gives negative (then imaginary) numbers sometimes
            D = sqrt( bsxfun(@plus,sum(U{i}'.^2,2),sum(U{j}'.^2,2)') - 2*(U{i}'*U{j}) )';
            A = 1./(1+real(D));
        else
            %A = U{i}'*U{j}; %not normalized!
            %D = pdist2(U{i}',U{j}','cosine');
            
            normA = sqrt(sum(U{i} .^ 2, 1))';
            normB = sqrt(sum(U{j} .^ 2, 1));
            D = 1-bsxfun(@rdivide, bsxfun(@rdivide, U{i}' * U{j}, normA), normB)';
            A = 1-D;
        end
        tp = tp+cputime-t;
        
        if useLabels
            nli = double(nls{i});
            nlj = double(nls{j});

            label_dist = (nli*ones(1,length(nlj)))'-(nlj*ones(1,length(nli)));
            label_sim = 1.0*(label_dist==0);
            
            if strcmp(labelFun,'sum')
                W = A+label_sim;
            else % 'delta'
                W = A.*label_sim;
            end
        else
            W = A;
        end
        
        t = clock;
        [a] = bipartite_matching(W);
        tm = tm+etime(clock,t);
%         
%         [w t tio] = approx_matching(W);
%         tw = tw + t;
%         twio = twio + tio;
%         
%         t1 = clock;
%         [m2 w2] = hungarian_melin(W);
%         tb = tb + etime(clock,t1);
%         
%         t1 = clock;
%         [ass] = slam_match(W);
%         I = find(ass>0);
%         w2 = sum(W(sub2ind(size(W),1:length(I))',ass(I)));
%         ts = ts + etime(clock,t1);
%         
        K(i,j) = a;
        K(j,i) = a;
        
    end
%     keyboard
end
K_i = K;
tk = etime(clock,tk);

% -- Definite kernel
K_d = K_i+eye(N)*(0.001-min(eig(K_i)));

K = K_d;