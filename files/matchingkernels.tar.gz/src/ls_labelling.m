function [U,K] = ls_labelling(A, d)

%LS_LABELLING Returns the geometric 
%   representation of Luz & Schrijver of the graph 
%   specified by the adjacency matrix A.
%
%   U = LS_LABELLING(A) returns the Luz & Schrijver
%   representation of A. Each row of U is a coordinate 
%   and each column a vector corresponding to a node in A.
%
%   U = LS_LABELLING(A,d) returns the above with 
%   all vectors padded with zeros to dimension d>n.
%
%   [U, K] = LS_LABELLING(A,..) returns the both U
%   and K = U'U
%
%   Copyright (c) 2013, Fredrik Johansson 
%   frejohk@chalmers.se

if(nargin<2)
    d = size(A,1);
end

n = size(A,1);
N = size(A,2);

if(d<n)
    error('Smaller dimension than number of nodes.');
end

rho = -min(eig(A))+0.001;

K = A/rho + eye(size(A,1));

U = chol(K);

if(d>n)
    U = [U; zeros(d-n,N)];
end
