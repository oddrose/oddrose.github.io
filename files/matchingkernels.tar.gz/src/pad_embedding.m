function Ps = pad_embedding(Us,d)

N = length(Us);
Ps = cell(N,1);
for i=1:N
    U = Us{i};
    n = size(U,2);
    di = size(U,1);
    assert(di <= d);
    Ps{i} = [U; zeros(d-di,n)];
end
