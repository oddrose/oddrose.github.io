function M = incidence_matrix(A)

n = size(A,1);

% TODO: DOESN'T WORK FOR DIRECTED, WEIGHTED GRAPHS YET!
% IS IT DEFINED FOR THEM?
% WORKS FOR WEIGHTED UNDIRECTED...

%if(norm(A-A')<eps) % If undirected 
%(norm of sparse doesn't work on ttitania)
    [I,J] = find(triu(A));
    W = A(sub2ind(size(A),I,J));
%else
%    [I,J] = find(A);
%    W = A(sub2ind(size(A),I,J));
%end
    
nE = length(I);

E = 1:nE;
    
M = sparse([E, E]',... 
           [I; J],... 
           [sqrt(W); -sqrt(W)],... 
           nE,n);


if ~issparse(A)
    M = full(M);
end