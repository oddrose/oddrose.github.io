function [data, labels, embeds] = load_collection(name,useEmbeds)

%LOAD_COLLECTION Loads a dataset of graphs from
%   a collection of known sets, by name
%
%   [data, labels, embed] = LOAD_COLLECTION(NAME) 
%   returns the dataset and labels with name
%   equal to NAME (ignoring case), 
%   among the following: 
%
%   MUTAG, ENZYMES, NCI1, NCI109, DD
%
%   Copyright (c) 2014, Fredrik Johansson 
%   frejohk@chalmers.se

if nargin<2
    useEmbeds = false;
end

path = getenv('DIR_DATA');
embedPath = getenv('DIR_EMBEDS');

if strcmpi(name,'MUTAG') || ...
    strcmpi(name,'ENZYMES') || ...
    strcmpi(name,'NCI1') || ...
    strcmpi(name,'NCI109') || ...
    strcmpi(name,'NCI1S') || ...
    strcmpi(name,'PC00') || ...
    strcmpi(name,'PC05') || ...
    strcmpi(name,'PC10') || ...
    strcmpi(name,'PC15') || ...
    strcmpi(name,'PC20') || ...
    strcmpi(name,'PC25') || ...
    strcmpi(name,'PC30') || ...
    strcmpi(name,'PC35') || ...
    strcmpi(name,'PC40') || ...
    strcmpi(name,'ER00') || ...
    strcmpi(name,'ER05') || ...
    strcmpi(name,'ER10') || ...
    strcmpi(name,'ER15') || ...
    strcmpi(name,'ER20') || ...
    strcmpi(name,'ER25') || ...
    strcmpi(name,'ER30') || ...
    strcmpi(name,'ER35') || ...
    strcmpi(name,'ER40') || ...
    strcmpi(name,'ER45') || ...
    strcmpi(name,'ER50') || ...
    strcmpi(name,'PTCMR') || ...
    strcmpi(name,'PTCFR') || ...
    strcmpi(name,'PTCMM') || ...
    strcmpi(name,'PTCFM') || ...
    strcmpi(name,'DD')

    path = [path,'/collection'];
end
if strcmpi(name,'BURSI')
    path = [path,'/bursi'];
end

fpath = [path,'/',name,'.mat'];

if strcmpi(name(1:3),'PTC')
    fpath = [path,'/PTC.mat'];
end

if(exist(fpath,'file'))

    load(fpath)

    if strcmpi(name,'MUTAG')
       data = MUTAG;
       labels = lmutag;
       embeds = {};
       if useEmbeds
           epath = [embedPath,'/MUTAG_labellings.mat'];
           if exist(epath,'file')
               load(epath);
               embeds = struct('LO',{Ls.U});
           end
       end
    elseif strcmpi(name,'ENZYMES')
       data = ENZYMES;
       labels = lenzymes;
       embeds = {};
       if useEmbeds
           epath = [embedPath,'/ENZYMES_labellings.mat'];
           if exist(epath,'file')
               load(epath);
               embeds = struct('LO',{Ls.U});
           end
       end
    elseif strcmpi(name,'NCI1')
       data = NCI1;
       labels = lnci1;
       embeds = {};
       if useEmbeds
           epath = [embedPath,'/NCI1_labellings.mat'];
           if exist(epath,'file')
               load(epath);
               embeds = struct('LO',{Ls.U});
           end
       end
    elseif strcmpi(name,'NCI1S')
       data = NCI1S;
       labels = lnci1s;
       embeds = {};
       if useEmbeds
           epath = [embedPath,'/NCI1S_labellings.mat'];
           if exist(epath,'file')
               load(epath);
               embeds = struct('LO',{Ls.U});
           end
       end
    elseif strcmpi(name,'NCI109')
       data = NCI109;
       labels = lnci109;
       embeds = {};
       if useEmbeds
           epath = [embedPath,'/NCI109_labellings.mat'];
           if exist(epath,'file')
               load(epath);
               embeds = struct('LO',{Ls.U});
           end
       end
    elseif strcmpi(name,'DD')
       data = DD;
       labels = ldd;
       embeds = {};
       if useEmbeds
           epath = [embedPath,'/DD_labellings.mat'];
           if exist(epath,'file')
               load(epath);
               embeds = struct('LO',{Ls.U});
           end
       end
    elseif strcmpi(name,'PTCMR')
       I = find(lptc(:,1)~=3);
       data = PTC(I);
       labels = lptc(I,1);
       embeds = {}; 
       if useEmbeds
           epath = [embedPath,'/PTC_labellings.mat'];
           if exist(epath,'file')
               load(epath);
               embeds = struct('LO',{Ls(I).U});
           end
       end
    elseif strcmpi(name,'PTCFR')
       I = find(lptc(:,2)~=3);
       data = PTC(I);
       labels = lptc(I,2);
       embeds = {}; 
       if useEmbeds
           epath = [embedPath,'/PTC_labellings.mat'];
           if exist(epath,'file')
               load(epath);
               embeds = struct('LO',{Ls(I).U});
           end
       end
    elseif strcmpi(name,'PTCMM')
       I = find(lptc(:,3)~=3);
       data = PTC(I);
       labels = lptc(I,3);
       embeds = {}; 
       if useEmbeds
           epath = [embedPath,'/PTC_labellings.mat'];
           if exist(epath,'file')
               load(epath);
               embeds = struct('LO',{Ls(I).U});
           end
       end
    elseif strcmpi(name,'PTCFM')
       I = find(lptc(:,4)~=3);
       data = PTC(I);
       labels = lptc(I,4);
       embeds = {}; 
       if useEmbeds
           epath = [embedPath,'/PTC_labellings.mat'];
           if exist(epath,'file')
               load(epath);
               embeds = struct('LO',{Ls(I).U});
           end
       end
    elseif strcmpi(name(1:2),'PC')
       data = PC;
       labels = labels;
       embeds = {};
       if useEmbeds
           epath = [embedPath,'/',name,'_labellings.mat'];
           if exist(epath,'file')
               load(epath);
               embeds = struct('LO',{Ls.U});
           end
       end
    elseif strcmpi(name(1:2),'ER')
       data = ER;
       labels = ler;
       embeds = {};
       if useEmbeds
           epath = [embedPath,'/',name,'_labellings.mat'];
           if exist(epath,'file')
               load(epath);
               embeds = struct('LO',{Ls.U});
           end
       end
    elseif strcmpi(name,'BURSI')
       data = BURSI;
       labels = lbursi;
       embeds = {};
    end
else
    error(sprintf('Couldnt find dataset of name: %s',name'));
end