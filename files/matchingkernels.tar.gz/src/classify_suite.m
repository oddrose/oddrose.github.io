function R = classify_suite(K,Ki,labels,opt)

defaults = struct(...
    'verbose',false,...
    'kernelLabel','kernel',...
    'folds',10,...
    'nLandmarks',100,...
    'nAverages',10,...
    'onlylandmarks',false...
    );

opt = structunion(defaults,opt);

kernelLabel = opt.kernelLabel;

N = size(K,1);

R = struct('cv',[],'c',[],'g',[],'cvs',[],'accs',[],'label',[]);
R(1) = [];

folds = opt.folds;
svmparams = sprintf('-q -t 4 -v %d',folds);
cs = [0.0005 0.001 0.01 0.1 1 2 5 10 100];
% cs = 10.^(-7:2:7);
gs = [1/N];

if ~opt.onlylandmarks
    Ktrain= [(1:N)' K];
    r = cross_validate_fit(labels,Ktrain,svmparams,cs,gs);
    r.label = sprintf('%s',kernelLabel);
    R(end+1) = r;
    if opt.verbose
        fprintf('%s\n%.3f%%\n',r.label,r.cv);
    end

    Ktrain= [(1:N)' Ki];
    r = cross_validate_fit(labels,Ktrain,svmparams,cs,gs);
    r.label = sprintf('%s: (Indef)',kernelLabel);
    R(end+1) = r;
    if opt.verbose
        fprintf('%s\n%.3f%%\n',r.label,r.cv);
    end
end

opt.mode = 'kernel'; opt.cs = cs; opt.gs = gs;
[acc,~,~,accs] = landmark_cv(Ki,labels,opt);
r = struct();
r.cv = acc; r.c = []; r.g = []; r.cvs = []; r.accs = accs;
r.label = sprintf('%s: Landmarks',kernelLabel);
R(end+1) = r;
if opt.verbose
    fprintf('%s\n%.3f%%\n',r.label,r.cv);
end

if ~opt.onlylandmarks
    Ktrain= [(1:N)' normalizekm(K)];
    r = cross_validate_fit(labels,Ktrain,svmparams,cs,gs);
    r.label = sprintf('%s: (Norm.)',kernelLabel);
    R(end+1) = r;
    if opt.verbose
        fprintf('%s\n%.3f%%\n',r.label,r.cv);
    end

    Ktrain= [(1:N)' normalizekm(Ki)];
    r = cross_validate_fit(labels,Ktrain,svmparams,cs,gs);
    r.label = sprintf('%s: (Indef. Norm.)',kernelLabel);
    R(end+1) = r;
    if opt.verbose
        fprintf('%s\n%.3f%%\n',r.label,r.cv);
    end

    opt.mode = 'kernel'; opt.cs = cs; opt.gs = gs;
    [acc,~,~,accs] = landmark_cv(normalizekm(Ki),labels,opt);
    r = struct();
    r.cv = acc; r.c = []; r.g = []; r.cvs = []; r.accs = accs;
    r.label = sprintf('%s: Landmarks (Norm.)',kernelLabel);
    R(end+1) = r;
    if opt.verbose
        fprintf('%s\n%.3f%%\n',r.label,r.cv);
    end
end
