function L = graph_laplacian(A,normalize)

%GRAPH_LAPLACIAN Returns the graph laplacian 
%   of the graph specified by the adjacency 
%   matrix A. 
%
%   L = GRAPH_LAPLACIAN(A) returns the graph
%   laplacian of A
%
%   L = GRAPH_LAPLACIAN(A,NORMALIZE) returns 
%   the normalized graph laplacian of A if
%   NORMALIZE is true.
%
%   Copyright (c) 2013, Fredrik Johansson 
%   frejohk@chalmers.se


% Does this just work for undirected graphs???

if(nargin<2)
    normalize = false;
end
   

if(issparse(A))
    A = full(A);
end

if(~normalize)
    D = diag(sum(A,1));
    L = D-A;
else
    n = size(A,1);
    d = sum(A,1);
    
    if(isempty(find(d==0)))
        E = diag(d.^(-1/2));
        L = eye(n)-E*A*E;
    else % If there are isolated vertices
        D = diag(d);
        L = D-A;
        t = d.^(-1/2);
        t(isinf(t))=0;
        T = diag(t);
        L = T*L*T;
    end
    if(isnan(L(1,1)) || isinf(L(1,1)))
        keyboard
    end
end



