function r = cross_validate_fit(labels,K,opt,cs,gs,kernel)

%CROSS_VALIDATE_FIT Fits C-SVM parameters to the data K
%   using the supplied labels. The set of values of C and
%   gamma are supplied as cs and gs. The function requires
%   LIBSVM: http://www.csie.ntu.edu.tw/~cjlin/libsvm/
%   and that the LIBSVM catalog is specified in the 
%   environment variable 'LIBSVMHOME'.
%
%   R = CROSS_VALIDATE_FIT(L,K) returns a result set
%   R for classifying the data in K with labels
%   L. R has fields cv, the best cross-validation 
%   accuracy, c, the best value of C, and g, the best
%   value of gamma. 
%
%   The default values of cs and gs are [0.001 0.1 1 2 10]
%   and 1/N respectively, where N are the number of columns 
%   in K.
%
%   R = CROSS_VALIDATE_FIT(L,K,OPT) returns the above with
%   additional libsvm parameters specified as a string
%   in OPT.
%
%   R = CROSS_VALIDATE_FIT(L,K,OPT,cs) returns the above 
%   with the range of C specified by cs. 
%
%   R = CROSS_VALIDATE_FIT(L,K,OPT,cs,gs) returns the above 
%   with the range of gamma specified by gs. 
%
%   Copyright (c) 2013, Fredrik Johansson 
%   frejohk@chalmers.se

if(nargin<6)
    kernel = true;
end

if(nargin < 4 || isempty(cs))
    cs = [0.05 0.1 0.5 1 5 10 500];
end
N = size(K,2);
if(nargin < 5 || isempty(gs))
    gs = 1/N;
end

SVMROOT = getenv('LIBSVMHOME');


cvs = [];
for i=1:length(cs)
    c = cs(i);
    for j=1:length(gs)
        g = gs(j);
        opt = sprintf('%s -s 0 -c %.3f -g %.3f',opt,c,g);
        
%         acc = libsvmtrain(labels,K,opt);
%         cvs(i,j) = acc;

        kernelFile = sprintf('cv-kernel-%d.tmp',round(cputime*100));
        accFile = sprintf('cv-acc-%d.tmp',round(cputime*100));
        
        svm_write_data(K(:,2:end), kernelFile, labels, kernel); 
        unix(sprintf('%s/svm-train %s %s %s >/dev/null', SVMROOT, opt, kernelFile, accFile));
        
        acc = importdata(accFile);
        cvs(i,j) = acc;

        delete(kernelFile);
        delete(accFile);
    end
end


[cv i] = max(cvs,[],1);
[cv j] = max(cv);
c = cs(i(j));
g = gs(j);

r = struct();
r.cv = cv;
r.c = c;
r.g = g;
r.cvs = cvs;
r.accs = [];