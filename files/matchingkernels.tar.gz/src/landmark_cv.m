function [cv_acc, S, margin, all_accs] = landmark_cv(data,labels,opt)

if nargin<3
    opt = struct();
end

defaults = struct(...
    'mode','kernel',...
    'simfun',@(x,y) x'*y,...
    'nLandmarks',100,...
    'nAverages',5,...
    'folds',10',...
    'verbose',false,...
    'cs',[0.0005 0.001 0.01 0.1 1 2 5 10 100],...
    'normalizefeatures',true,...
    'gs',1/100);

opt = structunion(defaults, opt);

N = size(data,1); 

Ntr = N-round(N/opt.folds);
Nte = N-Ntr;
        
nLand = opt.nLandmarks;
if nLand>Ntr
    nLand = Ntr;
end

% -- Precompute similarities for CV
if strcmp(opt.mode,'vector')
    S = zeros(N,N);
    for i = 1:N
        progresscount(i,1,N);
        for j=i:N
            s = simfun(data(i),data(j));
            S(i,j) = s;
            S(j,i) = s;
        end
    end
else
    S = data;
end

nAvg = opt.nAverages;
avg_acc = zeros(1,length(opt.cs));
avg_margin = zeros(1,length(opt.cs));
all_accs = zeros(nAvg,length(opt.cs));
for a=1:nAvg
    accs = zeros(opt.folds,length(opt.cs));
    margins = zeros(opt.folds,length(opt.cs));
    
    for f=1:opt.folds
        if opt.verbose
            progresscount((a-1)*opt.folds+f,1,nAvg*opt.folds);
        end
        P = randperm(N); % NOT CORRECT FOLDING!
        
        Itr = P(1:Ntr);
        Ite = P((Ntr+1):end);
        Ila = Itr(1:nLand);
%         Ila = Itr(landmark_heuristic(S(Itr,Itr), nLand));
        F = S(:,Ila);
        
        % normalize landmark features
        if opt.normalizefeatures
            F = F-repmat(mean(F,1),N,1);
            F = F./repmat(std(F,1),N,1);
        end
%         F = F./repmat(max(abs(F),[],1),N,1);

        Ftr = F(Itr,:);    Fte = F(Ite,:);
        ltr = labels(Itr); lte = labels(Ite);
        
        for ci = 1:length(opt.cs)
            % TRAINING
            args = sprintf('-t 0 -c %d -q -g %d',opt.cs(ci),opt.gs(1));
%             args = sprintf('-t 2 -c %d -q -g %d -gamma 0.001',opt.cs(ci),opt.gs(1));
            model = libsvmtrain(ltr,Ftr,args);
%             args = sprintf('-t 4 -c %d -q -g %d',opt.cs(ci),opt.gs(1));
%             model = libsvmtrain(ltr,[[1:Ntr]', Ftr'*Ftr],args);

            if(length(unique(labels))==2)
                Y = labels(Itr(model.sv_indices))*2-1;
                X = real(F(Itr(model.sv_indices),:));
                Z = ((Y.*model.sv_coef)*ones(1,size(X,2)))';
                w = sum(Z.*X',2);
                marg = 2/norm(w);
            else
                marg = 0;
            end

            % TESTING
            l = svmpredict(lte,Fte,model,'-q');
%             l = svmpredict(labels(Ite),[[1:Nte]' Fte'*Ftr],model,'-q');
            acc_c = sum(l==lte)/length(Ite);
            accs(f,ci) = acc_c;
            margins(f,ci) = marg;
        end
    end
    avg_acc = avg_acc+mean(accs,1)/nAvg;
    all_accs(a,:) = mean(accs,1);
    avg_margin = avg_margin+mean(margins,1)/nAvg;
end
[acc i] = max(avg_acc);

cv_acc = 100*acc;
margin = avg_margin(i);
