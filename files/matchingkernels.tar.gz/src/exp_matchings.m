    function Rs = exp_matchings(datasets, opt, e_fields, e_labels, kernels)

if nargin<3 || isempty(e_fields)
    e_fields = {'L','IL','ES','ELS','LS','IM'};
    e_labels = {'Laplacian','Inverse Laplacian','Adjacency spectrum',...
            'Laplacian spectrum','LS-labelling','Incidence Matrix'};
end
if nargin==3
    error('Cant supply embedding types without labels');
end

cmpkernels = true;
if nargin>4
    cmpkernels = false;
end

resultdir = getenv('DIR_RESULTS');

Rss = {};
for di=1:length(datasets)
    dataname = datasets{di};
    [data, labels, embeds] = load_collection(dataname,true);
    
    timestr = datestr(now,'yymmdd_HHMMSS-FFF');
    resultfile = sprintf('%s/%s_%s.mat',resultdir,timestr,dataname);
    logfile = sprintf('%s/%s_log_%s.txt',resultdir,timestr,dataname);
    embedfile = sprintf('%s/%s_embeds.mat',resultdir,dataname);
    resultfile = filename_increment(resultfile);
    logfile = filename_increment(logfile);

    if cmpkernels
        if nargin>3 && strcmp(e_fields{1},'LO') && length(e_fields)==1
            % --- embeddings loaded already
        else
            newEmbeds = embed_graphs(data,true);
            if isempty(embeds)
                % -- Do nothing
            else
                tmp = {embeds(:).LO}';
                [newEmbeds(:).LO] = deal(tmp{:});
            end
            embeds = newEmbeds;
            save(embedfile,'embeds','-v7.3');
        end
    end
    
    N = length(data);
    
    fprintf(1,'Running experiment with embeddings:\n');
    embeds
    
    if cmpkernels
        if opt.useLabels
            nl = {};
            for i=1:N
                nl{i}=data(i).nl.values;
            end
            wlLabels = WLlabels(data,opt.wlIterations,true);
        else
            wlLabels = {[]};
        end
        
        Ks = {};
        
    else
        Ks = kernels{di};
    end

    Rs = struct('cv',[],'c',[],'g',[],'cvs',[],'accs',[],'label',[],'runtime',[]);
    Rs(1) = [];
    
    %%
    for ie=1:length(e_fields)
        e_field = e_fields{ie};
        e_label = e_labels{ie};
        
        if cmpkernels
            Us = {embeds(:).(e_field)}';
            maxd = 0;
            for i=1:N
                maxd = max(maxd,size(Us{i},1));
            end
            Ps = pad_embedding(Us,maxd);

            K = zeros(N,N); Ki = zeros(N,N);
            for iwl=1:length(wlLabels)
                nl_wl = wlLabels{iwl};
                [K_wl Ki_wl runtime] = matching_kernel(Ps,opt.distance,nl_wl,true,opt.labelFun);
                K = K+K_wl; Ki = Ki+Ki_wl;
            end
        else
            Kps = Ks{ie};
            K = Kps{2};
            Ki = Kps{3};
            runtime = 0;
        end

        Ks{end+1} = {e_label,K,Ki};
        save(resultfile,'Rs','Ks');
        
        copt = opt;
        copt.kernelLabel = e_label;
        R = classify_suite(K,Ki,labels,copt);
        
        [R.runtime] = deal(runtime);
        Rs = [Rs;R'];
        S = log_experiment(opt,Rs,[],true);
        f = fopen(logfile,'w');
        fprintf(f,S);
        fclose(f);
        save(resultfile,'Rs','Ks');
    end
    
    %%
    for i=1:length(Rs)
        fprintf('%s\n%.3f%%\n',Rs(i).label,Rs(i).cv);
    end
    Rss{end+1} = Rs;
end
