
=== Installation instructions ===

1. Download and install Matlab Gaimc Toolbox
   http://www.mathworks.com/matlabcentral/fileexchange/24134-gaimc---graph-algorithms-in-matlab-code

2. Download and install LIBSVM
   http://www.csie.ntu.edu.tw/~cjlin/libsvm/

3. Edit setup.m
   - Set LIBSVMPATH and GAIMCPATH to the root dirs 
     of the respective library

4. (Optional) Set directories DIR_DATA, DIR_EMBEDS to directories where
   datasets and embeddings are stored. (Can be overridden in 
   experiment configs)

5. Run setup.m 

6. (Optional) Try out example1.m