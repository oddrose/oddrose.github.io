function S = sample_weights(nSamples,d_range,ns, scheme)

N = length(ns);

mind = d_range(1);
maxd = d_range(2);
nBins = maxd-mind+1;

S = [];
if(strcmp(scheme,'uniform'))
    S = ones(nBins,N)*floor(nSamples/nBins);    
elseif(strcmp(scheme,'log'))    
    w = zeros(nBins,N);    
    sampleWeights = zeros(nBins,N);
    
    for i=1:N
        nActiveBins = min(maxd,ns(i))-mind+1;
        for d=mind:min(maxd,ns(i))
            w(d-mind+1,i) = nchoosek(ns(i),d);
        end  
        wi = log(w(:,i)+1);
        sampleWeights(:,i) = wi/sum(wi);
        S(:,i) = ceil(sampleWeights(:,i)*(nSamples-nActiveBins));
        S(1:nActiveBins,i) = S(1:nActiveBins,i) + 1;        
    end
else
    w = zeros(nBins,N);    
    sampleWeights = zeros(nBins,N);
    
    for i=1:N
        nActiveBins = min(maxd,ns(i))-mind+1;
        for d=mind:min(maxd,ns(i))
            w(d-mind+1,i) = nchoosek(ns(i),d);
        end  
        wi = w(:,i);
        sampleWeights(:,i) = wi/sum(wi);
        S(:,i) = ceil(sampleWeights(:,i)*(nSamples-nActiveBins));
        S(1:nActiveBins,i) = S(1:nActiveBins,i) + 1;
    end    
end
