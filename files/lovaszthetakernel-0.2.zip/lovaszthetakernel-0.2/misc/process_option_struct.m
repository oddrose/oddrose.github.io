function opt = process_option_struct(opts, names, defaults)

opt = opts; % Adds at least all original options

if(length(names) ~= length(defaults))
    error('Inequal number of names and default values');
end

if(~isempty(names))
    nNames = length(names);
    
    for i=1:nNames
        if(~isfield(opts,names{i}))
            opt.(names{i}) = defaults{i};
        end
    end

end