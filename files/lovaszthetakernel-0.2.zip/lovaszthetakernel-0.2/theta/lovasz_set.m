function Ls = lovasz_set(graphs,outfile,resume)

cvx_clear

N = length(graphs);

Us = {};
cs = {};
Xs = {};
ts = {};

writeOut = true;

if nargin<2
    outfile = '';
    writeOut = false;
end
if nargin<3
    resume = false;
end

if(resume && writeOut)
    if(exist(outfile,'file'))
        load(outfile);
    end
end

if(exist('last','var'))
    last0 = last;
else
    last0 = length(Us);
end

runtimes = {};

fprintf(1,'Computing Lovasz labellings...\n');
for i=(last0+1):N
    fprintf(1,'%d/%d\n',i,N);
    A = graphs(i).am;
    t0 = cputime;
    [Us{i}, cs{i}, ts{i}, Xs{i}] = theta_vectors(A);
    runtimes{i} = cputime-t0;
    last = i;
    if writeOut
        save(outfile,'Us','cs','ts','Xs','runtimes','last');
    end
end
Ls = struct('U',Us,'c',cs,'t',ts,'X',Xs,'runtime',runtimes);

if writeOut
    save(outfile,'Ls','cs','ts','Xs','last');
end
