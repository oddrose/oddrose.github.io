% Puts last dimension (handle)
% first and makes all vectors have same dimension

function U = labelling_fix(Ls) 

d = 0;
for i=1:length(Ls);
   A = Ls(i).X; 
   d = max(d,size(A,1));
end

U = cell(length(Ls),1);
for i=1:length(Ls);
    u = theta_labelling(Ls(i).X,Ls(i).t,d+1,true);
    u = [u(end,:); u(1:end-1,:)];
    U{i} = u;
end

