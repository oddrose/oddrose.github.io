% Internal paths
addpath('./theta');
addpath('./kernels');
addpath('./kernels/svmtheta');
addpath('./misc');
addpath('./misc/minidisk');

setenv('CVXHOME','../../lib/cvx');
addpath(getenv('CVXHOME'));

addpath('../../lib/svm-theta-master/src');

