function [K, runtime] = lovasz_kernel(Gs,opt)

% --- Set up default parameters
if(nargin<2)
    opt = struct();
end
opt = process_option_struct(opt,...
    {'nSamples','sigma','maxSubsetSize','useAngle','uniSamples',...
    'minSubsetSize',...
    'verbose','alwaysMaxD','nMinSamples','kernel','theta'},...
    {100,0.1,inf,false,true,1,true,false,0,'gaussian',false});


embeds = lovasz_set(Gs);
embeds = {embeds.U}';

[K, runtime] = mec_kernel(embeds,opt.nSamples,opt.sigma,opt);