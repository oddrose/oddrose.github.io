function [K runtime] = mec_kernel(U,nSamples,sigma,opt)

N = length(U);

% --- Set up default parameters
if(nargin<4)
    opt = struct();
end
opt = process_option_struct(opt,...
    {'maxSubsetSize','useAngle','uniSamples','minSubsetSize',...
    'verbose','alwaysMaxD','nMinSamples','kernel','theta'},...
    {inf,false,true,1,true,false,0,'gaussian',false});

% --- Compute smallest number of points
maxn = 0;
for i=1:N
    maxn = max(maxn,size(U{i},2));
end

% --- Sample a bunch of subsets for each labelling
A = zeros(N,nSamples);
D = zeros(N,nSamples);
f_avg = zeros(N,min(maxn,opt.maxSubsetSize));

tstart = cputime;
if(opt.verbose)
    fprintf(1,'Sampling and computing angles...\n');
end
for i=1:N
    if(opt.verbose)
        progresscount(i,1,N);
    end
    u = U{i};
    n = size(u,2);
    
    maxd = min(opt.maxSubsetSize,n);
    w = ones(maxd,1);
    if(~opt.uniSamples)
        for d=1:maxd
            w(d) = nchoosek(n,d);
        end
    end
    w = w/sum(w);
    
    smpls = floor(w*nSamples);
        
    for r=1:(nSamples-sum(smpls))
        ri = mod(r-1,maxd)+1;
        smpls(ri) = smpls(ri)+1;
    end
    for d=1:length(smpls)
        smpls(d) = max(smpls(d),opt.nMinSamples);
    end
    
% %     smpls = round(w*nSamples); %todo: does not give sum=nSamples
%     smpls = mnrnd(nSamples,w); %todo: remove random component
%     if(sum(smpls)~=nSamples)
%         keyboard
%     end

    ds = opt.minSubsetSize:maxd;
    if(maxd < n && opt.alwaysMaxD)
        ds = [ds n];
    end

    si = 1;
    for d=ds
        S = [];
        if(d<n)
            for k=1:smpls(d)
                P = randperm(n);
                p = P(1:d);
                v = u(:,p);

                if(d>1)
                    t = minimum_cone(v);
                    if(~opt.useAngle)
                        t = cos(t);
                    end
                else
                    t = 0;
                end

                if(~isreal(t))
                    error('Imaginary angle, t');
                end

                A(i,si) = t;
                D(i,si) = d;
                si = si+1;
                S(k) = t;
            end
        elseif(d==n)
            if(opt.theta)
                t = opt.theta(i);
            else
                t = minimum_cone(u);
            end
            if(~opt.useAngle)
                t = cos(t);
            end
            A(i,si) = t;
            D(i,si) = d;
            si = si+1;
            S = t;
        end
        if(sum(S)~=0)
            f_avg(i,d) = mean(S);
        else
            f_avg(i,d) = 0;
        end
    end
end

% --- Compute Kernel matrix
K = zeros(N,N);
for i=1:N
    if(opt.verbose)
        fprintf(1,'Computing kernel row for set %d/%d\n',i,N);
    end
    for j=i:N
        k = 0;    
        if(strcmp(opt.kernel,'linear'))
            k = f_avg(i,:)*f_avg(j,:)';
        else
            nmin = min(size(U{i},2),size(U{j},2));
            maxd = min(nmin,opt.maxSubsetSize);
            ds = opt.minSubsetSize:maxd;
            if(maxd < nmin && opt.alwaysMaxD)
                ds = [ds nmin];
            end

            for d=ds
                kd = 0;
                smpls_i = A(i,D(i,:)==d);
                smpls_j = A(j,D(j,:)==d);
                nSamples_i = length(smpls_i);
                nSamples_j = length(smpls_j);
                if(nSamples_i > 0 && nSamples_j > 0) 
                    % Linear kernel
    %                 k = k + f_avg(i,d)*f_avg(j,d);
                    % RBF kernel
                    R1 = smpls_i'*ones(1,nSamples_j);
                    R2 = ones(nSamples_i,1)*smpls_j;
                    R = rbf_kernel(R1,R2,sigma);
                    kd = kd + sum(R(:));
                    k = k+kd/(nSamples_i*nSamples_j);
                end            
            end
        end
        K(i,j) = k;
        K(j,i) = k;
    end
end
runtime = cputime-tstart;
% D = diag(1./sqrt(diag(K)));
% K = D * K * D;