function [K, runtime, out] = svm_theta_kernel_subgraph_l(Gs,nSamples,opt)

if(nargin<2)
    nSamples = 20;
end
if(nargin<3)
    opt = struct();
end

opt = process_option_struct(opt,...
    {'verbose','samplingWeights','kernel','samplingScheme',...
    'divideByD','laplacian','alphaOutput','precomputedAlpha',...
    'tolerance','sigma'},...
    {false,'log','linear','convergence',...
    false,false,false,{},10^-4,1});

N = length(Gs);

mind = 1;
minSamples = 5;

tstart = cputime;
maxLabel = 0;
% -- COMPUTE ALPHAS ---------------------------------------------
if(isempty(opt.precomputedAlpha))
    alphas = {};
    ns = [];
    fprintf(1,'Computing SVM-theta...\n');
    maxSumAlpha = 0;
    for i=1:N
        if(opt.verbose)
            progresscount(i,1,N);
        end
        if(opt.laplacian) 
            A = graph_laplacian(Gs(i).am,false);
        else
            A = Gs(i).am;
        end
        alphas{i} = svm_theta_alpha(A);
        ns(i) = size(Gs(i).am,1);
        maxSumAlpha = max(sum(alphas{i}),maxSumAlpha);
    end
else
    alphas = opt.precomputedAlpha;
    ns = [];
    maxSumAlpha = 0;
    for i=1:N
        ns(i) = size(Gs(i).am,1);
        maxSumAlpha = max(sum(alphas{i}),maxSumAlpha);
    end
end


if(opt.alphaOutput)
    save(opt.alphaOutput,'alphas');
end

minn = min(ns);
maxd = max(ns);

nBins = maxd-mind+1;

nSamplesPer = zeros(nBins,N);
if(~strcmp(opt.samplingScheme,'convergence'))
    nSamplesPer = sample_weights(nSamples, [mind, maxd], ns, opt.samplingWeights);
end

K = zeros(N,N);

avgAlphas = zeros(nBins,N);
mean_diffs = zeros(nBins,1);

sample_a = zeros(N,nSamples);
sample_d = zeros(N,nSamples);
sample_labels = cell(N,nSamples);

for i=1:N
    maxLabel = max(maxLabel,max(Gs(i).nl.values));
end

% -- SAMPLE SUBSETS ----------------------------------------------
fprintf(1,'Sampling subsets...\n');

for i=1:N
    if(opt.verbose)
        progresscount(i,1,N);
    end
    
    alpha = alphas{i};
    n = size(Gs(i).am,1);
    si = 1;
    maxdi = min(maxd,n);
    for d=mind:maxdi
        alpha_d = [];
        
        if(strcmp(opt.samplingScheme,'convergence'))
            k = 0;
            mean_diff = inf;
            mean_last = inf;
            while(mean_diff > opt.tolerance && k<nSamples)
                k = k+1;
                P = randperm(n);
                p = P(1:d);        
                a =  sum(alpha(p));
                alpha_d(end+1) = a;
                
                sample_a(i,si) = a;
                sample_d(i,si) = d;
                sample_labels{i,si} = Gs(i).nl.values(p);
                sample_labels{i,si} = histc(sample_labels{i,si},1:maxLabel);
                if d==1
                    sample_labels{i,si} = sample_labels{i,si}';
                end
                
                si = si+1;
                if(k>minSamples)
                    mean_diff = sum((mean_last-mean(alpha_d)).^2)/sum(mean(alpha_d).^2);
                end
                mean_last = mean(alpha_d);
            end    
            nSamplesPer(d,i) = k;
            mean_diffs(d) = mean_diff;
        else
            for s=1:nSamplesPer(d-mind+1,i)
                P = randperm(n);
                p = P(1:d);        
                a =  sum(alpha(p));
                alpha_d(end+1) = a;
                
                sample_a(i,si) = a;
                sample_d(i,si) = d;
                
                sample_labels{i,si} = Gs(i).nl.values(p);
                sample_labels{i,si} = histc(sample_labels{i,si},1:maxLabel);
                if d==1
                    sample_labels{i,si} = sample_labels{i,si}';
                end
                
                si = si+1;
            end
        end
        avgAlphas(d-mind+1,i) = mean(alpha_d);
    end
end


% -- COMPUTE KERNEL ----------------------------------------------
fprintf(1,'Computing SVM-theta kernel...\n');

for i=1:N
    if(opt.verbose)
        progresscount(i,1,N);
    end
    for j=i:N
        ds = mind:min([maxd ns(i) ns(j)]);
        if(strcmp(opt.kernel,'linear'))
            ads = mind:(size(avgAlphas)+mind-1);
            a1 = avgAlphas(:,i);
            if(opt.divideByD)
                a1 = a1./ads;
            end
            k = a1'*avgAlphas(:,j);
            
        else % -- Gaussian kernel 
            k = 0;
            for d=ds
                kd = 0;
                
                smpls_i = sample_a(i,sample_d(i,:)==d);
                smpls_j = sample_a(j,sample_d(j,:)==d);
                nSamples_i = length(smpls_i);
                nSamples_j = length(smpls_j);
                
                labels_i = [sample_labels{i,sample_d(i,:)==d}];
                labels_j = [sample_labels{j,sample_d(j,:)==d}];
                
                R_l = labels_i'*labels_j>0;
                
                
                if(nSamples_i > 0 && nSamples_j > 0) 
                    R1 = smpls_i'*ones(1,nSamples_j);
                    R2 = ones(nSamples_i,1)*smpls_j;
                    
                    R = rbf_kernel(R1,R2,opt.sigma);
                    
                    try
                        R = R.*R_l;
                    catch 
                        keyboard
                    end
                    kd = kd + sum(R(:));
                    kd = kd/(nSamples_i*nSamples_j);
                end     
                
                if(opt.divideByD)
                    kd = kd/d;
                end
                k = k+kd;
            end
        end
        
        K(i,j) = k;
        K(j,i) = k;
    end
end

out = struct();
out.alphas = alphas;
out.nSamplesPer = nSamplesPer;

runtime = cputime-tstart;
