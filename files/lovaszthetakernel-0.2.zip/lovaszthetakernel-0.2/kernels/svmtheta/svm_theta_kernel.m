%
% General SVM theta kernel
%
function [K, runtime, out] = svm_theta_kernel(Gs,opt)

opt = process_option_struct(opt,{'variant'},{'subgraph-label'});

data = {};
for i=1:length(Gs)
    data{i} = Gs(i).am;
end


if(strcmp(opt.variant,'subgraph'))
   [K, runtime, out] = ...
       svm_theta_kernel_subgraph(data,opt.samples,opt); 
   
elseif(strcmp(opt.variant,'subgraph-label'))
   [K, runtime, out] = ...
       svm_theta_kernel_subgraph_l(Gs,opt.samples,opt); 
   
elseif(strcmp(opt.variant,'matching'))
   [K, runtime, out] = ...
       svm_theta_kernel_matching(Gs,opt); 
   
elseif(strcmp(opt.variant,'alt'))
   [K, runtime, out] = ...
       svm_theta_kernel_alt(data,opt.samples,opt);
   
elseif(strcmp(opt.variant,'simple'))
    opt.nl = [Gs.nl];
    for i=1:length(Gs)
        opt.nl(i).values = opt.nl(i).values+1;
    end
   [K, runtime, out] = ...
       svm_theta_simple_kernel(data,opt);
   
else
    
    error(sprintf('Unknown variant of SVM theta kernel: %s',opt.variant));
end
