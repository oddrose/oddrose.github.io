%
% Computes the lovasz theta and svm-theta kernels for the MUTAG dataset.
%

% -- Add necessary paths

setup();

%% -- Load dataset
load MUTAG.mat
graphs = MUTAG;

%% -- Compute Lovasz-theta kernel

try
    cvx_clear()
catch e
    cvx_setup();
end

[K_lo T_lo] = lovasz_kernel(graphs(1:10));

%% -- Compute SVM-theta kernel

svmopt = struct();
svmopt.variant = 'subgraph';
svmopt.kernel = 'gaussian';
svmopt.samples = 500;
svmopt.tolerance = 1e-4;
svmopt.sigma = 0.1;
svmopt.verbose = true;
svmopt.alpha = 1;
svmopt.addDiag = false;

[K_svm T_svm] = svm_theta_kernel(graphs,svmopt);